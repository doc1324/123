# PacMan-Python
Here is the code for Pacman game written in python 3.8 version using Pygame
